'use client';
import { useState } from 'react';
import Image from 'next/image';
import { ArrowUpRight, Menu, X, ArrowRight, Globe2, Compass, Target, Layers3, Users, BarChart3, Lightbulb, ShieldCheck, ChevronDown } from 'lucide-react';

const copy = {
 id: {
  nav:['Beranda','Tentang CAKRA','Layanan','Pendekatan','Insights','Kontak'],
  eyebrow:'CUSTOMER EXPERIENCE CONSULTING & ADVISORY',
  hero:'Pengalaman Lebih Baik. Bisnis Lebih Kuat.',
  sub:'Mentransformasikan Customer Experience menjadi nilai bisnis yang berkelanjutan.',
  desc:'CAKRA — CX Nusantara adalah mitra konsultasi dan advisory Customer Experience yang membantu organisasi memahami pelanggan, merancang pengalaman yang lebih baik, dan menerjemahkan strategi CX menjadi hasil bisnis yang bermakna.',
  cta:'Jelajahi Layanan', talk:'Mari Bicara tentang CX',
  who:'Mitra Strategis untuk Transformasi Pengalaman.',
  whoDesc:'Kami membantu organisasi membangun kapabilitas bisnis yang berorientasi pada pelanggan melalui strategi, service design, advisory implementasi, dan perbaikan berkelanjutan.',
  what:'Mengubah Pemahaman Pelanggan menjadi Dampak Bisnis.',
  approach:'Dari Insight menuju Impact.',
  approachDesc:'Pendekatan terstruktur yang menghubungkan pemahaman pelanggan, prioritas bisnis, desain layanan, dan peningkatan berkelanjutan.',
  value:'Transformasi Berpusat pada Pelanggan, Dirancang untuk Hasil.',
  industries:'Memahami Tantangan di Berbagai Industri.',
  insights:'Perspektif tentang Pengalaman yang Lebih Baik.',
  final:'Mari Ciptakan Pengalaman yang Lebih Baik Bersama.',
  finalDesc:'Setiap transformasi yang bermakna dimulai dari pemahaman. Mari diskusikan bagaimana pengalaman pelanggan yang lebih baik dapat menciptakan nilai bagi organisasi Anda.',
  contact:'Mulai Percakapan', formTitle:'Ceritakan kebutuhan organisasi Anda.',
  name:'Nama lengkap', org:'Organisasi', position:'Jabatan', email:'Email bisnis', phone:'Telepon (opsional)', service:'Layanan yang diminati', needs:'Ceritakan kebutuhan atau tantangan bisnis Anda', consent:'Saya menyetujui penggunaan informasi ini untuk menindaklanjuti permintaan konsultasi.',
  send:'Kirim Permintaan', formNote:'Form ini masih dalam mode demonstrasi. Hubungkan endpoint atau CRM sebelum digunakan secara publik.',
  footer:'CAKRA — CX Nusantara adalah brand konsultasi yang dioperasikan oleh PT Solusi Pengalaman Digital Nusantara.',
  services:[
   ['Strategi & Transformasi CX','Menetapkan visi, strategi, prioritas, tata kelola, dan keselarasan organisasi.','Arah transformasi yang jelas dan terukur.'],
   ['CX Masterplan & Roadmap','Menyusun masterplan enterprise dan program transformasi yang dapat dijalankan.','Prioritas dan tahapan implementasi yang terarah.'],
   ['Riset Pelanggan & Journey Mapping','Memahami kebutuhan, perilaku, ekspektasi, pain points, dan moments of truth.','Keputusan berbasis pemahaman pelanggan.'],
   ['Service Design & Experience Innovation','Merancang layanan dan pengalaman terintegrasi dengan pendekatan human-centered.','Pengalaman yang lebih relevan dan seamless.'],
   ['CX Implementation Advisory','Mendampingi perencanaan eksekusi, koordinasi lintas fungsi, dan tata kelola.','Strategi yang bergerak menjadi aksi.'],
   ['Pengukuran & Kinerja CX','Membangun sistem pengukuran NPS, CSAT, CES, VoC, dan KPI pengalaman.','Visibilitas kinerja dan peluang perbaikan.'],
   ['Audit & Maturity Assessment','Menilai kematangan CX, tata kelola, journey, dan eksekusi operasional.','Peta kesenjangan dan prioritas peningkatan.'],
   ['Budaya & Kapabilitas Customer-Centric','Mengembangkan kepemimpinan, keterampilan, perilaku, dan kolaborasi.','Kapabilitas organisasi yang berkelanjutan.']
  ],
  values:['Pemahaman Pelanggan Lebih Mendalam','Pengalaman End-to-End yang Lebih Baik','Keselarasan Organisasi yang Lebih Kuat','Peningkatan Bisnis Berkelanjutan'],
  stages:[['Discover','Memahami ekspektasi pelanggan, prioritas bisnis, stakeholder, dan journey saat ini.'],['Diagnose','Menilai pengalaman, kinerja, service gaps, kapabilitas, dan peluang perbaikan.'],['Design','Mengembangkan strategi CX, future-state journey, service blueprint, dan prioritas.'],['Deliver','Mendukung perencanaan eksekusi, koordinasi, tata kelola, dan adopsi organisasi.'],['Optimize','Mengukur hasil, membaca feedback, dan menggerakkan continuous improvement.']],
  sectors:['Perbankan & Jasa Keuangan','Telekomunikasi & Teknologi','Transportasi & Mobilitas','Retail & Digital Commerce','Healthcare','Pemerintahan & Layanan Publik','Layanan Profesional & Enterprise'],
  about:'Tentang CAKRA', explore:'Pelajari CAKRA', servicesTitle:'Layanan Kami', industriesTitle:'Industri', company:'Informasi Perusahaan',
 },
 en: {
  nav:['Home','About CAKRA','Services','Our Approach','Insights','Contact'],
  eyebrow:'CUSTOMER EXPERIENCE CONSULTING & ADVISORY',
  hero:'Better Experiences. Stronger Business.',
  sub:'Transforming Customer Experience into Sustainable Business Value.',
  desc:'CAKRA — CX Nusantara is a Customer Experience consulting and advisory partner helping organizations understand their customers, design better experiences, and translate CX strategies into meaningful business outcomes.',
  cta:'Explore Our Services', talk:"Let's Talk CX",
  who:'A Strategic Partner for Experience Transformation.',
  whoDesc:'We help organizations build customer-centric business capabilities through strategy, service design, implementation advisory, and continuous improvement.',
  what:'We Turn Customer Understanding into Business Impact.',
  approach:'From Insight to Impact.',
  approachDesc:'A structured approach connecting customer understanding, business priorities, service design, and continuous improvement.',
  value:'Customer-Centric Transformation, Designed for Results.',
  industries:'Understanding Challenges Across Industries.',
  insights:'Perspectives on Better Experiences.',
  final:"Let's Shape Better Experiences Together.",
  finalDesc:"Every meaningful transformation starts with understanding. Let's explore how better customer experiences can create value for your organization.",
  contact:'Start a Conversation', formTitle:'Tell us about your organization’s needs.',
  name:'Full name', org:'Organization', position:'Position', email:'Business email', phone:'Phone (optional)', service:'Service of interest', needs:'Tell us about your project or business needs', consent:'I consent to the use of this information to follow up on my consultation inquiry.',
  send:'Submit Inquiry', formNote:'This form is currently a demonstration. Connect an endpoint or CRM before public use.',
  footer:'CAKRA — CX Nusantara is a consulting brand operated by PT Solusi Pengalaman Digital Nusantara.',
  services:[
   ['CX Strategy & Transformation','Define CX vision, strategy, priorities, governance, and organizational alignment.','A clear and measurable transformation direction.'],
   ['CX Masterplan & Roadmap','Design enterprise-wide CX masterplans and practical transformation programs.','Focused priorities and implementation stages.'],
   ['Customer Research & Journey Mapping','Understand customer needs, behaviors, expectations, pain points, and moments of truth.','Decisions grounded in customer understanding.'],
   ['Service Design & Experience Innovation','Design better services and integrated experiences through human-centered methods.','More relevant and seamless experiences.'],
   ['CX Implementation Advisory','Support execution planning, cross-functional coordination, and implementation governance.','Turn strategy into action.'],
   ['CX Measurement & Performance','Develop NPS, CSAT, CES, VoC, and experience KPI measurement systems.','Visibility into performance and improvement.'],
   ['CX Audit & Maturity Assessment','Assess CX maturity, governance, journeys, and operational execution.','A map of gaps and improvement priorities.'],
   ['Customer-Centric Culture & Capability','Develop leadership, skills, behaviors, and collaboration.','Sustainable organizational capability.']
  ],
  values:['Deeper Customer Understanding','Better End-to-End Experiences','Stronger Organizational Alignment','Sustainable Business Improvement'],
  stages:[['Discover','Understand customer expectations, business priorities, stakeholders, and current journeys.'],['Diagnose','Assess experiences, performance, service gaps, capabilities, and opportunities.'],['Design','Develop CX strategy, future-state journeys, service blueprints, and priorities.'],['Deliver','Support execution planning, cross-functional coordination, governance, and adoption.'],['Optimize','Measure outcomes, interpret feedback, and enable continuous improvement.']],
  sectors:['Banking & Financial Services','Telecommunications & Technology','Transportation & Mobility','Retail & Digital Commerce','Healthcare','Government & Public Services','Professional & Enterprise Services'],
  about:'About CAKRA', explore:'Discover CAKRA', servicesTitle:'Our Services', industriesTitle:'Industries', company:'Corporate Information',
 }
};

const icons = [Target, Layers3, Compass, Lightbulb, Users, BarChart3, ShieldCheck, Globe2];
const navIds = ['home','about','services','approach','insights','contact'];

export default function Home() {
 const [lang,setLang] = useState<'id'|'en'>('en');
 const [menu,setMenu] = useState(false);
 const [submitted,setSubmitted] = useState(false);
 const t = copy[lang];
 function go(id:string){ document.getElementById(id)?.scrollIntoView({behavior:'smooth'}); setMenu(false); }
 function submit(e:React.FormEvent<HTMLFormElement>){ e.preventDefault(); setSubmitted(true); }
 return <main>
  <header className="header"><a className="brand" href="#home" aria-label="CAKRA CX Nusantara"><Image src="/cakra-logo.png" alt="CAKRA — CX Nusantara" width={250} height={84} priority /></a>
   <nav className={menu?'nav open':'nav'} aria-label="Main navigation">{t.nav.map((n,i)=><button key={n} onClick={()=>go(navIds[i])}>{n}</button>)}</nav>
   <div className="head-actions"><button className="lang" onClick={()=>setLang(lang==='id'?'en':'id')} aria-label="Change language"><Globe2 size={15}/>{lang.toUpperCase()}</button><button className="nav-cta" onClick={()=>go('contact')}>{t.talk}<ArrowUpRight size={15}/></button><button className="mobile-toggle" onClick={()=>setMenu(!menu)} aria-label="Toggle menu">{menu?<X/>:<Menu/>}</button></div>
  </header>
  <section className="hero" id="home"><div className="hero-grid"></div><div className="hero-copy"><p className="eyebrow"><span></span>{t.eyebrow}</p><h1>{t.hero}</h1><p className="hero-sub">{t.sub}</p><p className="hero-desc">{t.desc}</p><div className="hero-actions"><button className="button-primary" onClick={()=>go('services')}>{t.cta}<ArrowUpRight size={17}/></button><button className="button-text" onClick={()=>go('contact')}>{t.talk}<ArrowRight size={17}/></button></div><div className="hero-foot"><span>01 / 05</span><span>STRATEGY · DESIGN · TRANSFORMATION</span></div></div>
   <div className="hero-art" aria-hidden="true"><div className="orb orb-one"></div><div className="orb orb-two"></div><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="art-core"><span>CAKRA</span><small>EXPERIENCE<br/>ECOSYSTEM</small></div><div className="art-label label-a">CUSTOMER</div><div className="art-label label-b">BUSINESS</div><div className="art-label label-c">PEOPLE</div><div className="art-caption">Meaningful connections.<br/>Measurable value.</div></div>
  </section>
  <section className="intro section" id="about"><div className="section-kicker">01 — {t.about}</div><div className="intro-grid"><h2>{t.who}</h2><div><p className="lead">{t.whoDesc}</p><p className="muted">{lang==='id'?'Kami percaya pengalaman pelanggan yang kuat dibangun melalui pemahaman yang mendalam, keputusan yang terarah, dan kemampuan organisasi untuk terus berkembang.':'We believe strong customer experiences are built through deep understanding, purposeful decisions, and an organization’s ability to keep evolving.'}</p><button className="inline-link" onClick={()=>go('company')}>{t.explore}<ArrowUpRight size={16}/></button></div></div></section>
  <section className="services section" id="services"><div className="section-top"><div><div className="section-kicker">02 — {t.servicesTitle}</div><h2>{t.what}</h2></div><p>{lang==='id'?'Solusi konsultasi yang dirancang untuk menjawab tantangan pengalaman pelanggan dan kebutuhan transformasi organisasi.':'Consulting solutions designed to address customer experience challenges and organizational transformation needs.'}</p></div><div className="service-grid">{t.services.map((s,i)=>{const Icon=icons[i];return <article className="service-card" key={s[0]}><div className="card-top"><span>0{i+1}</span><Icon size={21}/></div><h3>{s[0]}</h3><p>{s[1]}</p><div className="card-value"><span>{lang==='id'?'POTENSI NILAI':'POTENTIAL VALUE'}</span>{s[2]}</div><button aria-label={`Learn more about ${s[0]}`} onClick={()=>go('contact')}><ArrowUpRight size={18}/></button></article>})}</div></section>
  <section className="approach section" id="approach"><div className="section-kicker">03 — {lang==='id'?'PENDEKATAN KAMI':'OUR APPROACH'}</div><div className="approach-head"><h2>{t.approach}</h2><p>{t.approachDesc}</p></div><div className="stage-list">{t.stages.map((s,i)=><article className="stage" key={s[0]}><span className="stage-num">0{i+1}</span><div><h3>{s[0]}</h3><p>{s[1]}</p></div><ArrowUpRight className="stage-arrow" size={20}/></article>)}</div><p className="framework-note">{lang==='id'?'CAKRA CX Transformation Framework — kerangka kerja usulan yang dapat disesuaikan dengan kebutuhan dan konteks setiap organisasi.':'CAKRA CX Transformation Framework — a proposed framework that can be tailored to each organization’s needs and context.'}</p></section>
  <section className="value section"><div className="section-kicker">04 — {lang==='id'?'NILAI YANG KAMI CIPTAKAN':'VALUE WE CREATE'}</div><h2>{t.value}</h2><div className="value-grid">{t.values.map((v,i)=><div className="value-item" key={v}><span>0{i+1}</span><h3>{v}</h3></div>)}</div></section>
  <section className="industries section"><div className="section-kicker">05 — {t.industriesTitle}</div><div className="industry-head"><h2>{t.industries}</h2><p>{lang==='id'?'Setiap industri memiliki ekspektasi, journey, dan tantangan layanan yang berbeda. Pendekatan CX perlu memahami konteks tersebut.':'Every industry has distinct expectations, journeys, and service challenges. CX approaches need to understand that context.'}</p></div><div className="industry-list">{t.sectors.map((s,i)=><div key={s}><span>0{i+1}</span>{s}<ArrowUpRight size={17}/></div>)}</div></section>
  <section className="insights section" id="insights"><div className="section-kicker">06 — INSIGHTS</div><div className="insights-panel"><div><span className="eyebrow">{lang==='id'?'IDE & PERSPEKTIF':'IDEAS & PERSPECTIVES'}</span><h2>{t.insights}</h2><p>{lang==='id'?'Ruang untuk berbagi pemikiran, perspektif, dan wawasan seputar strategi Customer Experience, journey, service design, dan transformasi bisnis.':'A space for ideas, perspectives, and insights on Customer Experience strategy, journeys, service design, and business transformation.'}</p></div><span className="insight-mark">C.</span></div><p className="muted small-note">{lang==='id'?'Artikel dan publikasi akan ditampilkan setelah melalui proses editorial dan persetujuan.':'Articles and publications will appear after editorial review and approval.'}</p></section>
  <section className="contact section" id="contact"><div className="contact-copy"><div className="section-kicker">07 — CONTACT</div><h2>{t.final}</h2><p>{t.finalDesc}</p><div className="contact-detail"><span>CAKRA — CX NUSANTARA</span><p>Infinity Office, Bellezza BSA, 1st Floor, Unit 106<br/>Jl. Letjen Soepono, Kebayoran Lama<br/>Jakarta Selatan 12210, Indonesia</p><p className="contact-links"><a href="tel:+628119104049">+62 811-9104-049</a><br/><a href="mailto:sofa@cx-nusantara.id">sofa@cx-nusantara.id</a><br/><a href="https://www.cx-nusantara.id">www.cx-nusantara.id</a></p><a href="https://www.google.com/maps/search/?api=1&query=Infinity+Office+Bellezza+BSA+Unit+106+Jakarta+Selatan" target="_blank" rel="noreferrer">{lang==='id'?'Lihat lokasi':'View location'} <ArrowUpRight size={15}/></a></div></div>
   <form className="contact-form" onSubmit={submit}><h3>{t.formTitle}</h3>{submitted?<div className="success"><ShieldCheck size={24}/><strong>{lang==='id'?'Terima kasih atas minat Anda.':'Thank you for your interest.'}</strong><p>{lang==='id'?'Ini hanya konfirmasi demo. Belum ada data yang dikirim atau disimpan.':'This is a demo confirmation. No data has been sent or stored.'}</p><button type="button" className="inline-link" onClick={()=>setSubmitted(false)}>{lang==='id'?'Kirim simulasi lain':'Submit another demo'}</button></div>:<><div className="form-grid"><label>{t.name}<input required name="name" autoComplete="name"/></label><label>{t.org}<input required name="organization"/></label><label>{t.position}<input name="position"/></label><label>{t.email}<input required type="email" name="email" autoComplete="email"/></label><label>{t.phone}<input type="tel" name="phone"/></label><label>{t.service}<select required name="service"><option value="">—</option>{t.services.map(s=><option key={s[0]}>{s[0]}</option>)}</select></label></div><label className="full-label">{t.needs}<textarea required rows={4} name="needs"/></label><label className="consent"><input type="checkbox" required/> <span>{t.consent}</span></label><button className="button-primary submit" type="submit">{t.send}<ArrowUpRight size={17}/></button><p className="form-note">{t.formNote}</p></>}</form>
  </section>
  <section className="company section" id="company"><div><div className="section-kicker">{t.company}</div><h2>CAKRA <span>— CX Nusantara</span></h2><p>{lang==='id'?'Brand konsultasi Customer Experience yang dioperasikan oleh PT Solusi Pengalaman Digital Nusantara. Didirikan Juni 2026.':'A Customer Experience consulting brand operated by PT Solusi Pengalaman Digital Nusantara. Founded June 2026.'}</p></div><div className="company-meta"><div><span>{lang==='id'?'BADAN HUKUM':'LEGAL ENTITY'}</span><strong>PT Solusi Pengalaman Digital Nusantara</strong></div><div><span>{lang==='id'?'KEPEMIMPINAN':'LEADERSHIP'}</span><strong>Ms. Sofa Muzdalifah · Chief Executive Officer</strong></div><div><span>{lang==='id'?'KERANGKA KERJA':'FRAMEWORK'}</span><strong>Discover · Diagnose · Design · Deliver · Optimize</strong></div></div></section>
  <footer className="footer"><a className="brand footer-brand" href="#home"><Image src="/cakra-logo.png" alt="CAKRA — CX Nusantara" width={250} height={84} /></a><p>{t.footer}</p><div><span>© {new Date().getFullYear()} CAKRA — CX Nusantara</span><a href="#home">{lang==='id'?'Kembali ke atas':'Back to top'} ↑</a></div></footer>
 </main>;
}
