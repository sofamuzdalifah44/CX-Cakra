import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'CAKRA — CX Nusantara | Customer Experience Consulting',
  description: 'Strategic Customer Experience consulting and advisory. Designing Experiences. Creating Value.',
  metadataBase: new URL('https://www.cx-nusantara.id'),
  openGraph: { title: 'CAKRA — CX Nusantara', description: 'Your Strategic Partner in Customer Experience Transformation.', type: 'website' }
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
