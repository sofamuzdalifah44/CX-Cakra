# CAKRA — CX Nusantara

Premium bilingual corporate website starter for CAKRA — CX Nusantara, operated by PT Solusi Pengalaman Digital Nusantara.

## Included
- Responsive single-page corporate experience
- Bahasa Indonesia default and English language switcher
- Six navigation destinations represented in the page flow
- Eight consulting service cards
- Five-stage proposed CX framework
- Industry overview, Insights introduction, corporate identity and office details
- Consultation form UI with client-side required-field validation and demo confirmation
- SEO title, description and Open Graph basics
- Reduced-motion CSS support

## Run locally
1. Install Node.js 20 or later.
2. Extract this project.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open `http://localhost:3000`.

## Before production
This is a functional front-end starter, not a fully deployed production platform. The following items require owner decisions, credentials, and implementation:
- Replace `https://example.com` in `app/layout.tsx` with the approved domain.
- Connect the contact form to a secure server-side endpoint and CRM/email destination. The current form intentionally does not transmit or store personal data.
- Configure CMS and authenticated admin roles for service pages, bilingual articles, leadership content, and inquiry management.
- Add approved official logo and leadership portrait/bio.
- Obtain legal review for Privacy Policy, Terms of Use, consent wording, and Indonesian PDP obligations.
- Configure analytics, cookie/consent behavior if applicable, anti-spam, retention, backups, monitoring, and HTTPS at the hosting layer.
- Add final service detail pages and article routes before launch.
- Verify metadata, canonical URLs, sitemap, robots.txt, hreflang and structured data against the final domain and content.
- Run accessibility, security, browser, and performance testing.

## Content integrity
No client logos, testimonials, case studies, certifications, market-leadership claims, or fabricated publications are included. The CAKRA CX Transformation Framework is presented as a proposed adaptable framework, not a patented or certified methodology.


## Brand update
The official CAKRA logo is included at `public/cakra-logo.png` and applied to the site header and footer. Contact details for the CEO are included in the contact section. The inquiry form remains a front-end demo until connected to a CRM or backend.

## Deployment to Vercel

1. Extract this ZIP file.
2. Upload the extracted `cakra-cx-nusantara-updated` project to a GitHub repository.
3. In Vercel, choose **Add New → Project**, import that repository, and keep the detected Next.js settings.
4. Click **Deploy**. No environment variables are required for the current front-end preview.
5. Add your production domain in Vercel → Project → Settings → Domains.

The homepage now opens in English by default. The ID / EN control switches the page language. Contrast has been improved for body copy, muted text, form labels, footer text, and content on navy backgrounds.

Before public launch, connect the inquiry form to a secure CRM/API endpoint; the current form only shows a local demo confirmation and does not transmit or store submissions. Review legal/privacy content and run a final mobile/browser QA.
